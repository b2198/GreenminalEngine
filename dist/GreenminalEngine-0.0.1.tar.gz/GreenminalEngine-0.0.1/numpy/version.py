
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.17.1'
version = '1.17.1'
full_version = '1.17.1'
git_revision = '29759461091f9a4a40ff2f4ae2126e0a5af1fcdd'
release = True

if not release:
    version = full_version
